package ii_teste;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class interface_pedidos {

	private final SimpleStringProperty tipo;
	private final SimpleIntegerProperty id;
	private final SimpleStringProperty estado;
	private final SimpleIntegerProperty p1;
	private final SimpleIntegerProperty p2;
	private final SimpleIntegerProperty destino;
	private final SimpleIntegerProperty quantidade;	
	private final SimpleIntegerProperty p_produzidas;
	private final SimpleIntegerProperty p_fabrica;
	private final SimpleStringProperty h_pedido;
	private final SimpleStringProperty h_inicio;
	private final SimpleStringProperty h_fim;
	

	
	public interface_pedidos(String tipo, int id, String estado, int p1, int p2, int destino, int quantidade, int p_produzidas, int p_fabrica, String h_pedido, String h_inicio, String h_fim) {
			super();
			this.tipo = new SimpleStringProperty(tipo);
			this.id = new SimpleIntegerProperty(id);
			this.estado = new SimpleStringProperty(estado);
			this.p1 = new SimpleIntegerProperty(p1);
			this.p2 = new SimpleIntegerProperty(p2);
			this.destino = new SimpleIntegerProperty(destino);
			this.quantidade = new SimpleIntegerProperty(quantidade);
			this.p_produzidas = new SimpleIntegerProperty(p_produzidas);
			this.p_fabrica = new SimpleIntegerProperty(p_fabrica);
			this.h_pedido = new SimpleStringProperty(h_pedido);
			this.h_inicio = new SimpleStringProperty(h_inicio);
			this.h_fim = new SimpleStringProperty(h_fim);
	}

	public String getTipo() {
		return tipo.get();
	}

	public int getId() {
		return id.get();
	}	
	public String getEstado() {
		return estado.get();
	}

	public int getP1() {
		return p1.get();
	}

	public int getP2() {
		return p2.get();
	}

	public int getDestino() {
		return destino.get();
	}

	public int getQuantidade() {
		return quantidade.get();
	}

	public int getP_produzidas() {
		return p_produzidas.get();
	}

	public int getP_fabrica() {
		return p_fabrica.get();
	}
	
	public String getH_pedido() {
		return h_pedido.get();
	}

	public String getH_inicio() {
		return h_inicio.get();
	}
	
	public String getH_fim() {
		return h_fim.get();
	}
}
