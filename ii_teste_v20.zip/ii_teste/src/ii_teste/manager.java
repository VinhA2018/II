package ii_teste;

import ii_teste.Modbus;
import ii_teste.pedido;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ii_teste.XMLreader;
import ii_teste.cerebro;

public class manager extends Application{
	
	
	 public void start(Stage primaryStage) throws Exception {
		 
		 Parent root = FXMLLoader.load(getClass().getResource("main.fxml"));
		 Scene scene = new Scene(root);
		 primaryStage.setTitle("MES - II 2017/2018");
		 primaryStage.setScene(scene);
		 primaryStage.show();
	 }
	 
	public static void main(String[] args) {
		
		
		Runnable ges = new cerebro();
        Thread a = new Thread(ges);
        a.start(); 
        
        
    	Runnable UDP = new udp();
    	Thread b= new Thread(UDP);
    	b.start();
    		
    	
    	//	XMLreader ficheiro_pedido = new XMLreader();
    		//	ficheiro_pedido.readXMLfile(path);
        
    
        
        
	
        	launch(args);
		
	
	}
	
	

	
}
