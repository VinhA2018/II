package ii_teste;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import ii_teste.Modbus;
import ii_teste.pedido;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ii_teste.XMLreader;
import ii_teste.cerebro;

public class MainController implements Initializable {
	
	int aux=1;

	@FXML private Label db;
	@FXML private Label plc;
	
	@FXML private TableView<interface_maquinas> table_maquina;
	@FXML private TableColumn<interface_maquinas, String> maquineta;
	@FXML private TableColumn<interface_maquinas, Integer> celula;
	@FXML private TableColumn<interface_maquinas, Integer> p1;
	@FXML private TableColumn<interface_maquinas, Integer> p2;
	@FXML private TableColumn<interface_maquinas, Integer> p3;
	@FXML private TableColumn<interface_maquinas, Integer> p4;
	@FXML private TableColumn<interface_maquinas, Integer> p5;
	@FXML private TableColumn<interface_maquinas, Integer> p6;
	@FXML private TableColumn<interface_maquinas, Integer> p7;
	@FXML private TableColumn<interface_maquinas, Integer> p8;
	@FXML private TableColumn<interface_maquinas, Integer> p9;
	@FXML private TableColumn<interface_maquinas, Integer> total;
	@FXML private TableColumn<interface_maquinas, Integer> tempo;
	
	
	@FXML private TableView<interface_pedidos> table_pedidos;
	@FXML private TableColumn<interface_pedidos, String> tipo;
	@FXML private TableColumn<interface_pedidos, Integer> id;
	@FXML private TableColumn<interface_pedidos, String> estado;
	@FXML private TableColumn<interface_pedidos, Integer> destino;
	@FXML private TableColumn<interface_pedidos, Integer> pa;
	@FXML private TableColumn<interface_pedidos, Integer> pb;
	@FXML private TableColumn<interface_pedidos, Integer> quantidade;
	@FXML private TableColumn<interface_pedidos, Integer> p_produzidas;
	@FXML private TableColumn<interface_pedidos, Integer> p_fabrica;
	@FXML private TableColumn<interface_pedidos, String> h_pedido;
	@FXML private TableColumn<interface_pedidos, String> h_inicio;
	@FXML private TableColumn<interface_pedidos, String> h_fim;
	

	public void status(ActionEvent status_plc_db) {
	
	if (data_base.DB_OK == 1)
		db.setText("CONEX�O OK");
	else if (data_base.DB_OK != 1)
		db.setText("SEM CONEX�O");
	
	if (Modbus.plc_ok ==1)
		plc.setText("CONEX�O OK");
	if (Modbus.plc_ok !=1)
		plc.setText("SEM CONEX�O");
	
	}
	
	
	public void limpar_maq(ActionEvent event_maq_limp) {
	data_base.reset_maq();
	}
	
	public void actualizar_maq(ActionEvent event_maq_act) {
		
	      Maquina maq1;
	      Maquina maq2;
	      Maquina maq3;
	      Maquina maq4;
	      Maquina maq5;
	      Maquina maq6; 
	         	
	      maq1=data_base.ler_maq(1);
	      maq2=data_base.ler_maq(2);
	      maq3=data_base.ler_maq(3);
	      maq4=data_base.ler_maq(4);
	      maq5=data_base.ler_maq(5);
	      maq6=data_base.ler_maq(6);
	      
	      list1 = FXCollections.observableArrayList(
	  			new interface_maquinas("MAQ A",1,maq1.p1, maq1.p2, maq1.p3, maq1.p4, maq1.p5, maq1.p6, maq1.p7, maq1.p8, maq1.p9, maq1.total, maq1.tempo),
	  			new interface_maquinas("MAQ A",2,maq2.p1, maq2.p2, maq2.p3, maq2.p4, maq2.p5, maq2.p6, maq2.p7, maq2.p8, maq2.p9, maq2.total, maq2.tempo),
	  			new interface_maquinas("MAQ B",3,maq3.p1, maq3.p2, maq3.p3, maq3.p4, maq3.p5, maq3.p6, maq3.p7, maq3.p8, maq3.p9, maq3.total, maq3.tempo),
	  			new interface_maquinas("MAQ C",1,maq4.p1, maq4.p2, maq4.p3, maq4.p4, maq4.p5, maq4.p6, maq4.p7, maq4.p8, maq4.p9, maq4.total, maq4.tempo),
	  			new interface_maquinas("MAQ C",2,maq5.p1, maq5.p2, maq5.p3, maq5.p4, maq5.p5, maq5.p6, maq5.p7, maq5.p8, maq5.p9, maq5.total, maq5.tempo),
	  			new interface_maquinas("MAQ C",3,maq6.p1, maq6.p2, maq6.p3, maq6.p4, maq6.p5, maq6.p6, maq6.p7, maq6.p8, maq6.p9, maq6.total, maq6.tempo)
	  			);	
	      table_maquina.setItems(list1);
	    }    
	
	
	
	public void actualizar_pedidos(ActionEvent event_pedidos_act) {
	
		pedido PED = new pedido();
		
	if (aux!=data_base.id_max()) {
		for (int i = aux; i < data_base.id_max(); i++) {
			
		PED = data_base.ler_pedidos(i);	
		list2.add(new interface_pedidos(PED.tipo, i, PED.estado,PED.p1, PED.p2, PED.destino, PED.quantidade, PED.pecas_p, PED.pecas_fabrica, PED.H_pedido, PED.H_inicio, PED.H_fim));
		}
		
		aux = data_base.id_max();
		table_pedidos.setItems(list2);
	}
	}
	
	  public ObservableList<interface_maquinas> list1; 
	  
	  public ObservableList<interface_pedidos> list2 = FXCollections.observableArrayList(
				new interface_pedidos("0",0,"0",0,0,0,0,0,0,"0","0","0")
				);
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {		
		
		maquineta.setCellValueFactory(new PropertyValueFactory<interface_maquinas, String>("maquineta"));
		celula.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("celula"));
		p1.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p1"));
		p2.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p2"));
		p3.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p3"));
		p4.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p4"));
		p5.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p5"));
		p6.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p6"));
		p7.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p7"));
		p8.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p8"));
		p9.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("p9"));
		tempo.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("tempo"));
		total.setCellValueFactory(new PropertyValueFactory<interface_maquinas, Integer>("total"));
		table_maquina.setItems(list1);
		
		tipo.setCellValueFactory(new PropertyValueFactory<interface_pedidos, String>("tipo"));
		id.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("id"));
		estado.setCellValueFactory(new PropertyValueFactory<interface_pedidos, String>("estado"));
		destino.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("destino"));
		pa.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("pa"));
		pb.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("pb"));
		quantidade.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("quantidade"));
		p_produzidas.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("p_produzidas"));
		p_fabrica.setCellValueFactory(new PropertyValueFactory<interface_pedidos, Integer>("p_fabrica"));
		h_pedido.setCellValueFactory(new PropertyValueFactory<interface_pedidos, String>("h_pedido"));
		h_inicio.setCellValueFactory(new PropertyValueFactory<interface_pedidos, String>("h_inicio"));
		h_fim.setCellValueFactory(new PropertyValueFactory<interface_pedidos, String>("h_fim"));
		table_pedidos.setItems(list2);		
	}	
	
}
	

