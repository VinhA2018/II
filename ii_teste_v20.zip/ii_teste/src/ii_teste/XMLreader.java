package ii_teste;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class XMLreader {

	public static int numero_encomenda;
	public static String tipo;
	public static String from;
	public static String to;
	public static int quantity;
	
	public void readXMLfile(String path){

    try {

	File fXmlFile = new File(path);
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
			
	//optional, but recommended
	//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
	NodeList nList = doc.getElementsByTagName("Order");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);
				
		System.out.println("\nCurrent Element :" + nNode.getNodeName());
				
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
			numero_encomenda = Integer.parseInt(eElement.getAttribute("Number"));
			}
	}
	
	NodeList nList1 = doc.getElementsByTagName("Transform");

	for (int temp = 0; temp < nList1.getLength(); temp++) {

		Node nNode = nList1.item(temp);
				
		tipo = nNode.getNodeName();
		
		
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

			from = eElement.getAttribute("From");
			to = eElement.getAttribute("To");
			quantity = Integer.parseInt(eElement.getAttribute("Quantity"));
			
			
			String P1[] = from.split ("");
			String P2[] = to.split (""); 
			
			System.out.println("NUMBER: " + numero_encomenda);
			System.out.println("TYPE: : " + tipo);
			System.out.println("FROM: : " + Integer.parseInt(P1[1]));
			System.out.println("TO: : " + Integer.parseInt(P2[1]));
			System.out.println("QUANTITY: : " + quantity);
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        Date date = new Date(); 
       
	        data_base.criar_pedido_producao(Integer.parseInt(P1[1]), Integer.parseInt(P2[1]), quantity ,dateFormat.format(date));
	
			
		}
	}
	
	
	NodeList nList2 = doc.getElementsByTagName("Unload");
	
	for (int temp = 0; temp < nList2.getLength(); temp++) {

		Node nNode = nList2.item(temp);
		tipo = nNode.getNodeName();
		
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

		
			from = eElement.getAttribute("Type");
			to = eElement.getAttribute("Destination");
			quantity = Integer.parseInt(eElement.getAttribute("Quantity"));
						
			String P1[] = from.split ("");
			String P2[] = to.split (""); 
			
			System.out.println("NUMBER: " + numero_encomenda);
			System.out.println("TYPE: : " + tipo);
			System.out.println("FROM: : " + Integer.parseInt(P1[1]));
			System.out.println("TO: : " + Integer.parseInt(P2[1]));
			System.out.println("QUANTITY: : " + quantity);
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        Date date = new Date(); 
			
			data_base.criar_pedido_descarga(Integer.parseInt(P1[1]), Integer.parseInt(P2[1]), quantity, dateFormat.format(date));
			
		}
	}
	
	NodeList nList3 = doc.getElementsByTagName("CreatePair");
	
	for (int temp = 0; temp < nList3.getLength(); temp++) {

		Node nNode = nList3.item(temp);
		tipo = nNode.getNodeName();
		
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

			from = eElement.getAttribute("Bottom");
			to = eElement.getAttribute("Top");
			quantity = Integer.parseInt(eElement.getAttribute("Quantity"));
			
			String P1[] = from.split ("");
			String P2[] = to.split (""); 
			
			System.out.println("NUMBER: " + numero_encomenda);
			System.out.println("TYPE: : " + tipo);
			System.out.println("FROM: : " + Integer.parseInt(P1[1]));
			System.out.println("TO: : " + Integer.parseInt(P2[1]));
			System.out.println("QUANTITY: : " + quantity);
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        Date date = new Date(); 
			
			data_base.criar_pedido_montagem(Integer.parseInt(P1[1]), Integer.parseInt(P2[1]), quantity, dateFormat.format(date));
			 
		}
	}
		
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

}