package ii_teste;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class interface_maquinas {
	
	private final SimpleStringProperty maquineta;
	private final SimpleIntegerProperty celula;
	private final SimpleIntegerProperty p1;
	private final SimpleIntegerProperty p2;
	private final SimpleIntegerProperty p3;
	private final SimpleIntegerProperty p4;	
	private final SimpleIntegerProperty p5;
	private final SimpleIntegerProperty p6;
	private final SimpleIntegerProperty p7;
	private final SimpleIntegerProperty p8;
	private final SimpleIntegerProperty p9;
	private final SimpleIntegerProperty total;
	private final SimpleIntegerProperty tempo;
	
	public interface_maquinas(String maquineta, int celula, int p1, int p2, int p3, int p4, int p5, int p6, int p7, int p8, int p9, int total,int tempo) {
			super();
			this.maquineta = new SimpleStringProperty(maquineta);
			this.celula = new SimpleIntegerProperty(celula);
			this.p1 = new SimpleIntegerProperty(p1);
			this.p2 = new SimpleIntegerProperty(p2);
			this.p3 = new SimpleIntegerProperty(p3);
			this.p4 = new SimpleIntegerProperty(p4);
			this.p5 = new SimpleIntegerProperty(p5);
			this.p6 = new SimpleIntegerProperty(p6);
			this.p7 = new SimpleIntegerProperty(p7);
			this.p8 = new SimpleIntegerProperty(p8);
			this.p9 = new SimpleIntegerProperty(p9);
			this.total = new SimpleIntegerProperty(total);
			this.tempo = new SimpleIntegerProperty(tempo);
	}

	public String getMaquineta() {
		return maquineta.get();
	}

	public int getCelula() {
		return celula.get();
	}	
	public int getP1() {
		return p1.get();
	}

	public int getP2() {
		return p2.get();
	}

	public int getP3() {
		return p3.get();
	}

	public int getP4() {
		return p4.get();
	}

	public int getP5() {
		return p5.get();
	}

	public int getP6() {
		return p6.get();
	}

	public int getP7() {
		return p7.get();
	}

	public int getP8() {
		return p8.get();
	}

	public int getP9() {
		return p9.get();
	}

	public int getTotal() {
		return total.get();
	}

	public int getTempo() {
		return tempo.get();
	}
}
