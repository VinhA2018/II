/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ii_teste;

/**
 *
 * @author ee11183
 */
public class Recolha_Armazem implements Runnable{
    
    public void run()
    {   
       
        int id_pedido=0;
//        int[] ids=new int[1];
        boolean[] Peca_entra_armazem=new boolean[1];
        boolean[] Saidas=new boolean[1];
     
        while(1==1)
        {
          try{
              
          Saidas=Modbus.Ler_Saida_Bool1(, 1);  //(endere�o inicial, quantidade)
          if(Saidas[0]==true) 
           {
               Peca_entra_armazem[0]=true; //pe�a a entrar
         
//               System.out.print(ids[0]);
               
//               id_pedido=ids[0]/10;  
               
               System.out.print(id_pedido);
               Modbus.Escrever_Saida_Bool(0, Peca_entra_armazem); // (endere�o inicial, valor) //pe�a est� a entrar
               data_base.incrementar_peca_concluida(id_pedido);
               Peca_entra_armazem[0]=false;  //pe�a j� entrou
               Modbus.Escrever_Saida_Bool(0, Peca_entra_armazem); 
                while(Saidas[0]==true)
                 {
                    Saidas=Modbus.Ler_Saida_Bool(1, 1); 
                }
           }
         }
         catch(Exception ex)
          {
             System.out.print(ex);
          }
          
        //FAZER PARA TODOS
        }
}
}