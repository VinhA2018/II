package ii_teste;

public class Maquina {
    int tempo;
    int p1;
    int p2;
    int p3;
    int p4;
    int p5;
    int p6;
    int p7;
    int p8;
    int total;
    
     public void Maquina( int total,int p1,int p2,int p3,int p4,int p5,int p6,int p7,int p8,int tempo)
     {
             this.tempo=tempo;
             this.p1=p1;
             this.p2=p2;
             this.p3=p3;
             this.p4=p4;
             this.p5=p5;
             this.p6=p6;
             this.p7=p7;
             this.p8=p8;
             this.total=total;
     }
}
