package ii_teste;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class XMLreader {

	public static int numero_encomenda;
	public static String tipo;
	public static String from;
	public static String to;
	public static int quantity;
	
	public void readXMLfile(String path){

    try {

	File fXmlFile = new File(path);
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
			
	//optional, but recommended
	//read this - http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
			
	NodeList nList = doc.getElementsByTagName("Order");
			
	//System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);
				
		System.out.println("\nCurrent Element :" + nNode.getNodeName());
				
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

		//	System.out.println("Ordem numero : " + eElement.getAttribute("Number"));
			numero_encomenda = Integer.parseInt(eElement.getAttribute("Number"));
			}
	}
	
	NodeList nList1 = doc.getElementsByTagName("Transform");
	
//	System.out.println("----------------------------");

	for (int temp = 0; temp < nList1.getLength(); temp++) {

		Node nNode = nList1.item(temp);
				
	//	System.out.println("\nCurrent Element :" + nNode.getNodeName());
		tipo = nNode.getNodeName();
		
		
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

	//		System.out.println("De pe�a : " + eElement.getAttribute("From"));
			from = eElement.getAttribute("From");
	//		System.out.println("Para pe�a : " + eElement.getAttribute("To"));
			to = eElement.getAttribute("To");
		//	System.out.println("Quantidade : " + eElement.getAttribute("Quantity"));
			quantity = Integer.parseInt(eElement.getAttribute("Quantity"));
		}
	}
	
	
	NodeList nList2 = doc.getElementsByTagName("Unload");
	
//	System.out.println("----------------------------");

	for (int temp = 0; temp < nList2.getLength(); temp++) {

		Node nNode = nList2.item(temp);
	
	//	System.out.println("\nCurrent Element :" + nNode.getNodeName());
		
		tipo = nNode.getNodeName();
		
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

		//	System.out.println("Pe�a : " + eElement.getAttribute("Type"));
			from = eElement.getAttribute("Type");
		//	System.out.println("Para : " + eElement.getAttribute("Destination"));
			to = eElement.getAttribute("Destination");
		//	System.out.println("Quantidade : " + eElement.getAttribute("Quantity"));
			quantity = Integer.parseInt(eElement.getAttribute("Quantity"));
		}
	}
	
	NodeList nList3 = doc.getElementsByTagName("CreatePair");
	
	for (int temp = 0; temp < nList3.getLength(); temp++) {

		Node nNode = nList3.item(temp);
				
	//	System.out.println("\nCurrent Element :" + nNode.getNodeName());
		
		tipo = nNode.getNodeName();
		
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;

		//	System.out.println("Pe�a : " + eElement.getAttribute("Type"));
			from = eElement.getAttribute("Bottom");
		//	System.out.println("Para : " + eElement.getAttribute("Destination"));
			to = eElement.getAttribute("Top");
		//	System.out.println("Quantidade : " + eElement.getAttribute("Quantity"));
			quantity = Integer.parseInt(eElement.getAttribute("Quantity"));
		}
	}
	
/*	System.out.println("NUMBER: " + numero_encomenda);
	System.out.println("TYPE: : " + tipo);
	System.out.println("FROM: : " + from);
	System.out.println("TO: : " + to);
	System.out.println("QUANTITY: : " + quantity);
*/
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

}