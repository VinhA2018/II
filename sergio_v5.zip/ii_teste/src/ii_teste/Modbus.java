package ii_teste;

import java.io.IOException;

import de.re.easymodbus.modbusclient.ModbusClient;

public class Modbus {
	
public static ModbusClient modbusClient = new ModbusClient();
	
	public void Init() {
		
	
	
	try
	{
	
		modbusClient.Connect("172.22.129.171",502);
		System.out.println("Conex�o estabelecida ao PLC");
	
				
	}
	catch (IOException e)
	{
		System.out.println("Erro de conex�o ao PLC");
	
	}
	}

	/*
	 * Fun��o com o objetivo de ler registos, etc
	 */
	public static int[] Ler_Saida_Registos(int registo, int n) throws Exception 
	{
		
		int[] saida = modbusClient.ReadInputRegisters(registo,  n);
		return saida;
	}
	
	
	public static void Escrever_Saida_Registos(int registo, int[] data) throws Exception 
	{
		modbusClient.WriteMultipleRegisters(registo, data);		
	}
	
	public static boolean[] Ler_Saida_Bool(int input, int n) throws Exception 
	{
		
		boolean[] saida = modbusClient.ReadDiscreteInputs(input,  n);
		return saida;		
	}
	
	public static void Escrever_Saida_Bool(int coil, boolean[] data) throws Exception 
	{	
		modbusClient.WriteMultipleCoils(coil,data);		
	}
	
	
	/*  for (int i = 0; i < saida.length; i++)
	System.out.println("Input Register #"+i+": "+saida[i]);   */
		
	

}
