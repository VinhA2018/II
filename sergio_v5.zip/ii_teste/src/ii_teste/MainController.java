package ii_teste;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import ii_teste.Modbus;
import ii_teste.pedido;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ii_teste.XMLreader;
import ii_teste.cerebro;

public class MainController implements Initializable {

	@FXML private TableView<interface_maquinas> table_maquina;
	@FXML private TableColumn<interface_maquinas, Integer> p1;
	@FXML private TableColumn<interface_maquinas, Integer> p2;
	@FXML private TableColumn<interface_maquinas, Integer> p3;
	@FXML private TableColumn<interface_maquinas, Integer> p4;
	@FXML private TableColumn<interface_maquinas, Integer> p5;
	@FXML private TableColumn<interface_maquinas, Integer> p6;
	@FXML private TableColumn<interface_maquinas, Integer> p7;
	@FXML private TableColumn<interface_maquinas, Integer> p8;
	@FXML private TableColumn<interface_maquinas, Integer> p9;
	@FXML private TableColumn<interface_maquinas, Integer> total;
	@FXML private TableColumn<interface_maquinas, Integer> tempo;

	
	public void actualizar_maq(ActionEvent event_maq_act) {
		
	
		  
		  int p1=0;
		  int p2=0;
		  int p3=0;
		  int p4=0;
		  int p5=0;
		  int p6=0;
		  int p7=0;
		  int p8=0;
		  int p9=0;
		  int total = 0;
		  		  
		  
	      pedido req=new pedido();
	      req.tipo="inicio";
	      int horas=0, minutos=0, segundos=0; 
	      String estado=null;
	      Maquina maq;
	      
	    //  
	  //   data_base.incrementar_maq(1, 3, 1);
      
	     // myMessage.setText(Integer.toString(maq.p1));
         // System.out.println("VALOR:"+maq.p1);
	         	for(int i=0;i<6;i++)
	      {
	         		maq=data_base.ler_maq(i+1);
	         
	  //        horas=maq.tempo/3600;
	  //        minutos=(maq.tempo-horas*3600)/60;
	  //        segundos=maq.tempo-horas*3600-minutos*60;
	          
	          model.setValueAt(""+horas+"h "+minutos+"m "+segundos+"s", i, 1);
	          model.setValueAt(maq.p1, i, 2);
	          model.setValueAt(maq.p2, i, 3);
	          model.setValueAt(maq.p3, i, 4);
	          model.setValueAt(maq.p4, i, 5);
	          model.setValueAt(maq.p5, i, 6);
	          model.setValueAt(maq.p6, i, 7);
	          model.setValueAt(maq.p7, i, 8);
	          model.setValueAt(maq.p8, i, 9);
	          model.setValueAt(maq.total, i, 10);  */
	      	}
	
	/*
	
	
	
	
	
	
	@FXML private TableView<interface_maquinas>   table_maquinas;
	@FXML private TableColumn<interface_maquinas, >
	@FXML private TableColumn<interface_maquinas>
	@FXML private TableColumn<interface_maquinas>
	@FXML private TableColumn<interface_maquinas>
	@FXML private TableColumn<interface_maquinas>
	@FXML private TableColumn<interface_maquinas>
	 */

	public ObservableList<interface_maquinas> list = FXCollections.observableArrayList(
			new interface_maquinas
			
			
			
			
			
			
			
			
			
			
			)
		
		
	

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}	
	



}
	

