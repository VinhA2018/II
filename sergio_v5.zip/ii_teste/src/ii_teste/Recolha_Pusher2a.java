/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ii_teste;

/**
 *
 * @author ee11183
 */
public class Recolha_Pusher2a implements Runnable{
  public void run()
    {   
       
        int[] ids=new int[1];
        int id_pedido=0;
        int id_peca=0;
        boolean[] Saidas=new boolean[1];
     
        while(1==1)
        {
          try{
         
          ids=Modbus.Ler_Saida_Registos(2, 1);
          if(ids[0]!=0)
           {
               
               System.out.print(ids[0]);
               System.out.print("\n\n");
               
               id_pedido=ids[0]/10;
               
               System.out.print(id_pedido);
               System.out.print("\n\n");
               data_base.incrementar_peca_concluida(id_pedido);
               id_peca=ids[0];
                while(ids[0]==id_peca)
                 {
                  ids=Modbus.Ler_Saida_Registos(2, 1);
                }
           }
         }
         catch(Exception ex)
          {
             System.out.print(ex);
          }
          
        //FAZER PARA TODOS
        }   
}
}
