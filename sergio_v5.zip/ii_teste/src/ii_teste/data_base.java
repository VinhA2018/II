package ii_teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import ii_teste.Maquina;
import ii_teste.pedido;

public class data_base {
	
	private static Connection con;
	static Lock bloqueio = new ReentrantLock();
	
	public static void conexao() {

        String url = "jdbc:postgresql://db.fe.up.pt:5432/up201304931";
        String user = "up201304931";
        String password = "gR9tnsRds";
        
        try {
            Class.forName("org.postgresql.Driver");
        	con = DriverManager.getConnection(url, user, password);
            System.out.println("Opened database successfully");
        } catch (ClassNotFoundException | SQLException ex) {
        System.out.println("ERROR:"+ex);
         }               
		}
	
	public static void criar_pedido_producao(int p1, int p2, int q, String data){
        try {
        	 int id_pedido=0;
             Statement st;
             ResultSet rs;
             
             st=con.createStatement();
             System.out.println("aqui");
             rs=st.executeQuery("Select id From pedidos ORDER by id");
             System.out.println("aqui2");

             while (rs.next()){
                  id_pedido= rs.getInt("id");
              }
              rs.close();
              id_pedido++; //id do novo pedido
              System.out.println(""+id_pedido+"");
              st.executeUpdate("INSERT INTO pedidos (id, tipo, p1, p2, quantidade, h_pedido) Values (  '"+id_pedido+"', 'producao','"+p1+"', '"+p2+"', '"+q+"', '"+data+"' )" );
              st.close(); 	
              System.out.println("Pedido introduzido"); 
        }
		catch (SQLException ex) {
		System.out.println("ERROR:"+ex);
		}
		
	}
	
	public static void criar_pedido_montagem(int pb, int pc, int q, String data){
        try {
        int id_pedido=0;
        Statement st;
        ResultSet rs;
         
        st=con.createStatement();
        
        rs=st.executeQuery("Select id From pedidos ORDER by id");
        while (rs.next()){
             id_pedido= rs.getInt("id");
         }
         rs.close();
 
        id_pedido++;
        System.out.println(""+id_pedido+"");
        st.executeUpdate("INSERT INTO pedidos (id, tipo, p1, p2, quantidade, h_pedido) Values (  '"+id_pedido+"', 'montagem','"+pb+"', '"+pc+"', '"+q+"','"+data+"' )" );
        st.close();
   
        System.out.println("Pedido introduzido");
        }
        catch (SQLException ex) {
           System.out.println("ERROR:"+ex);
      }
   }
 
	public static void criar_pedido_descarga(int pb, int pc, int destino, String data){
        try {
        int id_pedido=0;
        Statement st;
        ResultSet rs;
        st=con.createStatement();
        rs=st.executeQuery("Select id From pedidos ORDER by id");
        
        while (rs.next()){
             id_pedido= rs.getInt("id");
         }
         rs.close();
 
        id_pedido++;
        System.out.println(""+id_pedido+"");
        st.executeUpdate("INSERT INTO pedidos (id, tipo, p1,destino, quantidade, h_pedido) Values (  '"+id_pedido+"', 'descarga','"+pb+"', '"+pc+"', '"+destino+"', '"+data+"' )" );
        st.close();
       
        System.out.println("Pedido introduzido");
        }
        catch (SQLException ex) {
           System.out.println("ERROR:"+ex);
      }
   }
 
	public static pedido ler_pedidos(int id){//Para ver se é possível fazer
	    try {
	    int p1=0;
	    int p2=0;
	    int quantidade=0;
	    int pecas_p=0;
	    int destino=0;
	    int pecas_fabrica=0;
	    String estado=null;
	    String tipo=null;
	    String H_pedido=null;
	    String H_inicio=null;
	    String H_fim=null;
	     Statement st;
	    ResultSet rs;
	    pedido req=new pedido();
	    
	    st=con.createStatement();
	    rs=st.executeQuery("Select tipo, p1, p2, destino, quantidade, pecas_p, estado, pecas_fabrica, h_pedido,h_inicio, h_fim From pedidos where id='"+id+"'");
	    
	    while(rs.next())
	    {
	    
	        tipo=rs.getString("tipo");
	
	            if ("producao".equals(tipo))
	              {
	                  p1= rs.getInt("p1");
	                  p2=rs.getInt("p2");
	                  quantidade=rs.getInt("quantidade");
	                  pecas_p=rs.getInt("pecas_p");
	                  estado=rs.getString("estado");
	                  pecas_fabrica=rs.getInt("pecas_fabrica");
	                  H_pedido=rs.getString("h_pedido");
	                  H_inicio=rs.getString("h_inicio");
	                  H_fim=rs.getString("h_fim");
	                          
	                
	                  req.pedido_producao(id, p1, p2, quantidade, pecas_p,pecas_fabrica, estado,H_pedido, H_inicio, H_fim );
	                  rs.close();
	                  st.close();
	                  return req;
	             }
	                if ("montagem".equals(tipo))
	              {
	                  p1= rs.getInt("p1");
	                  p2=rs.getInt("p2");
	                  quantidade=rs.getInt("quantidade");
	                  pecas_p=rs.getInt("pecas_p");
	                  estado=rs.getString("estado");
	                  pecas_fabrica=rs.getInt("pecas_fabrica");
	                   H_pedido=rs.getString("h_pedido");
	                  H_inicio=rs.getString("h_inicio");
	                  H_fim=rs.getString("h_fim");
	                
	                    req.pedido_montagem(id, p1, p2, quantidade, pecas_p,pecas_fabrica, estado,H_pedido, H_inicio, H_fim ); 
	                     rs.close();
	                     st.close();
	                 return req;
	             } 
	                     if ("descarga".equals(tipo))
	              {
	                  p1= rs.getInt("p1");
	                  destino=rs.getInt("destino");
	                  quantidade=rs.getInt("quantidade");
	                  pecas_p=rs.getInt("pecas_p");
	                  estado=rs.getString("estado");
	                  pecas_fabrica=rs.getInt("pecas_fabrica");  
	                  H_pedido=rs.getString("h_pedido");
	                  H_inicio=rs.getString("h_inicio");
	                  H_fim=rs.getString("h_fim");
	                
	                  req.pedido_descarga(id, p1, destino, quantidade, pecas_p,pecas_fabrica, estado, H_pedido, H_inicio, H_fim); 
	                  rs.close();
	                  st.close();
	                    
	                 return req;
	             }
	 
	    }
	        
	            req.sem_pedido();
	            rs.close(); 
	            st.close();
	            return req;
	        
	    }
	      catch (SQLException ex) {
	      System.out.println("ERROR:"+ex);
	     }
	return null;
	}
	
	
	public static void incrementar_peca_concluida(int id){
        int pecas_p=0, pecas_fabrica=0, quantidade=1;
        Statement st;
        ResultSet rs;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date(); 
      try{
       
          st=con.createStatement();
        
        rs=st.executeQuery("Select pecas_p,  pecas_fabrica, quantidade from pedidos Where id="+id+"");
         
        while (rs.next()){
             pecas_p=rs.getInt("pecas_p");
             pecas_fabrica=rs.getInt("pecas_fabrica");
             quantidade=rs.getInt("quantidade");
         }
        rs.close();
        System.out.print("invrementa peça\n");
         pecas_fabrica--;
         pecas_p++;
         
         if(pecas_p==quantidade)
         { 
            st.executeUpdate("UPDATE pedidos set pecas_p="+pecas_p+",pecas_fabrica="+pecas_fabrica+",estado='processado', h_fim='"+dateFormat.format(date)+"' WHERE id="+id+"");//acrescentar hora de conclusao
          
           }
         else{
             st.executeUpdate("UPDATE pedidos set pecas_p="+pecas_p+",pecas_fabrica="+pecas_fabrica+"WHERE id="+id+"");
           
         }
         st.close();
       
      }
     catch (SQLException ex) {
          System.out.println("ERROR:"+ex);
         }
   }
	
	public static void incrementar_peca_fabrica(int id){
        int  pecas_fabrica=0;
        Statement st;
        ResultSet rs;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date(); 
        String estado=null;
     try{
       st=con.createStatement();
       
       rs=st.executeQuery("Select  pecas_fabrica, estado from pedidos Where id="+id+"");
        
       while (rs.next()){
            pecas_fabrica=rs.getInt("pecas_fabrica");
            estado=rs.getString("estado");
        }
       rs.close();
       System.out.print("aaa\n");
        pecas_fabrica++;
        
        if("por_processar".equals(estado))
        {
            st.executeUpdate("UPDATE pedidos set pecas_fabrica="+pecas_fabrica+", estado='a_processar', h_inicio='"+dateFormat.format(date)+"' WHERE id="+id+"");
            System.out.print("bbb\n");
        }
        else{ 
            st.executeUpdate("UPDATE pedidos set pecas_fabrica="+pecas_fabrica+" WHERE id="+id+"");//acrescentar hora de conclusao
            
        }
     }
    catch (SQLException ex) {
         System.out.println("ERROR:"+ex);
        }
  }
	
	
	 public static int id_max(){
	     
         Statement st;
         ResultSet rs;
         int id=0;   
     try{
         st=con.createStatement();
         
          rs=st.executeQuery("Select MAX(id) From pedidos ");
         
         while (rs.next()){
              id= rs.getInt("max");
          }
          rs.close();
      
       id++; 
       
     }
     catch (SQLException ex) {
           System.out.println("ERROR:"+ex);
           return 0;
          }
       return id;
     }
	 
	 public static pedido ler_pedidos_processar(int i){//Para ver se é possível fazer
         try {
         int id_ordem;
         int p1=0;
         int p2=0;
         int quantidade=0;
         int pecas_p=0;
         int destino=0;
         int pecas_fabrica=0;
         String estado=null;
         String tipo=null;
         String H_pedido=null;
         String H_inicio=null;
         String H_fim=null;
          Statement st;
         ResultSet rs;
         pedido req=new pedido();
         
         st=con.createStatement();
         rs=st.executeQuery("Select id, tipo, p1, p2, destino, quantidade, pecas_p, estado, pecas_fabrica, h_pedido,h_inicio, h_fim FROM ( SELECT ROW_NUMBER()OVER (ORDER BY id) AS ordem, id,tipo, p1, p2, destino, quantidade, pecas_p, estado, pecas_fabrica, h_pedido,h_inicio, h_fim FROM pedidos WHERE estado != 'processado') AS tabela1 WHERE ordem='"+i+"'"); 
         
         while(rs.next())
         {
         
             tipo=rs.getString("tipo");

                 if ("producao".equals(tipo))
                   {   
                       id_ordem=rs.getInt("id");
                       p1= rs.getInt("p1");
                       p2=rs.getInt("p2");
                       quantidade=rs.getInt("quantidade");
                       pecas_p=rs.getInt("pecas_p");
                       estado=rs.getString("estado");
                       pecas_fabrica=rs.getInt("pecas_fabrica");
                       H_pedido=rs.getString("h_pedido");
                       H_inicio=rs.getString("h_inicio");
                       H_fim=rs.getString("h_fim");
                       
                     
                       req.pedido_producao(id_ordem,p1, p2, quantidade, pecas_p,pecas_fabrica, estado,H_pedido, H_inicio, H_fim);
                       rs.close();
                       st.close();
                       return req;
                  }
                     if ("montagem".equals(tipo))
                   {     
                         id_ordem=rs.getInt("id");
                       p1= rs.getInt("p1");
                       p2=rs.getInt("p2");
                       quantidade=rs.getInt("quantidade");
                       pecas_p=rs.getInt("pecas_p");
                       estado=rs.getString("estado");
                       pecas_fabrica=rs.getInt("pecas_fabrica");
                        H_pedido=rs.getString("h_pedido");
                       H_inicio=rs.getString("h_inicio");
                       H_fim=rs.getString("h_fim");
                     
                         req.pedido_montagem(id_ordem, p1, p2, quantidade, pecas_p,pecas_fabrica, estado,H_pedido, H_inicio, H_fim ); 
                          rs.close();
                          st.close();
                      return req;
                  } 
                          if ("descarga".equals(tipo))
                   { 
                         id_ordem=rs.getInt("id");
                       p1= rs.getInt("p1");
                       destino=rs.getInt("destino");
                       quantidade=rs.getInt("quantidade");
                       pecas_p=rs.getInt("pecas_p");
                       estado=rs.getString("estado");
                       pecas_fabrica=rs.getInt("pecas_fabrica");  
                       H_pedido=rs.getString("h_pedido");
                       H_inicio=rs.getString("h_inicio");
                       H_fim=rs.getString("h_fim");
                     
                       req.pedido_descarga(id_ordem, p1, destino, quantidade, pecas_p,pecas_fabrica, estado, H_pedido, H_inicio, H_fim); 
                       rs.close();
                       st.close();
                         
                      return req;
                  }
      
         }
             
                 req.sem_pedido();
                 rs.close(); 
                 st.close();
                 return req;
             
         }
           catch (SQLException ex) {
           System.out.println("ERROR:"+ex);
          }
    return null;
}  
	 
	 public static int n_pecas_processadas(){
	     
         Statement st;
         ResultSet rs;
         int n=0;   
     try{
         st=con.createStatement();
         
          rs=st.executeQuery("Select COUNT(id) From pedidos WHERE estado!='processado' ");
         
         while (rs.next()){
              n= rs.getInt("count");
          }
          rs.close();
      
       n++; 
     }
     catch (SQLException ex) {
           System.out.println("ERROR:"+ex);
           return 0;
          }
       return n;
     }
	
	 public static int numero_pecas_processadas(){
	     
         Statement st;
         ResultSet rs;
         int id=0;   
     try{
         st=con.createStatement();
         
          rs=st.executeQuery("Select COUNT(id) From pedidos WHERE estado!='processado' ");
         
         while (rs.next()){
              id= rs.getInt("count");
          }
          rs.close();
      
       id++; 
     }
     catch (SQLException ex) {
           System.out.println("ERROR:"+ex);
           return 0;
          }
       return id;
     }
	 
	 
	 public static void reset_maq()
	    {
	        Statement st;
	        
	        try{
	        st=con.createStatement();
	        st.executeUpdate("UPDATE maquinas set total_pecas=0,p1=0,p2=0,p3=0,p4=0,p5=0,p6=0,p7=0,p8=0, tempo=0 ");  
	    
	        }
	        catch(Exception ex){
	            System.out.print(ex);
	        }
	    }
	 
	 
	 public static Maquina ler_maq(int i)
	    {
	         Statement st;
	         ResultSet rs;
	         Maquina maq=new Maquina();
	         int total=0;
	         int p1=0;
	         int p2=0;
	         int p3=0;
	         int p4=0;
	         int p5=0;
	         int p6=0;
	         int p7=0;
	         int p8=0;
	         int tempo=0;
	           try{
	            st=con.createStatement();
	            rs=st.executeQuery("SELECT * FROM (SELECT ROW_NUMBER()OVER (ORDER BY tipo,celula) AS ordem ,* FROM maquinas ) AS tab1 WHERE ordem="+i+"");
	             while(rs.next())
	            {
	                total=rs.getInt("total_pecas");
	                p1=rs.getInt("p1");
	                p2=rs.getInt("p2");
	                p3=rs.getInt("p3");
	                p4=rs.getInt("p4");
	                p5=rs.getInt("p5");
	                p6=rs.getInt("p6");
	                p7=rs.getInt("p7");
	                p8=rs.getInt("p8");
	                tempo=rs.getInt("tempo");
	            }
	             maq.Maquina(total, p1, p2, p3, p4, p5, p6, p7, p8, tempo);
	           }
	           catch(Exception ex)
	           {
	               System.out.print(ex);
	           }
	         return maq;
	    }
	 
	public static void incrementar_maq(int pa, int pb, int celula) /*so utilizado para 1->3*/{
	    Statement st;
	    ResultSet rs;
	    int total=0;
	    int p1=0;
	    int p2=0;
	    int p3=0;
	    int p4=0;
	    int p5=0;
	    int p6=0;
	    int p7=0;
	    int p8=0;
	    int tempo=0;
	     try{
	      
	       st=con.createStatement();
	       
	       
	       if(pa==1 && pb==3)
	           {     
	               
	                 rs=st.executeQuery("Select total_pecas,  p1, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p1=rs.getInt("p1");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p1++;
	                 tempo=tempo+5;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p1="+p1+", tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	           }
	       
	       else if(pa==3 && pb==5){
	            rs=st.executeQuery("Select total_pecas,  p3, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p3=rs.getInt("p3");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p3++;
	                 tempo=tempo+10;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p3="+p3+", tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	       else if(pa==5 && pb==7){
	            rs=st.executeQuery("Select total_pecas,  p4, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p5=rs.getInt("p4");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p5++;
	                 tempo=tempo+5;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p5="+p5+", tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	         else if(pa==2 && pb==4){
	            rs=st.executeQuery("Select total_pecas,  p2, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p2=rs.getInt("p2");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p2++;
	                 tempo=tempo+10;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p2="+p2+", tempo='"+tempo+"' WHERE tipo='B' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	           else if(pa==4 && pb==6){
	            rs=st.executeQuery("Select total_pecas,  p4, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p4=rs.getInt("p4");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 
	                 p4++;
	                 tempo=tempo+5;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p4="+p4+", tempo='"+tempo+"' WHERE tipo='B' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	           else if(pa==6 && pb==8){
	            rs=st.executeQuery("Select total_pecas, p4, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p4=rs.getInt("p6");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p6++;
	                 tempo=tempo+5;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p6="+p6+", tempo='"+tempo+"' WHERE tipo='B' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	           else if(pa==7 && pb==8){
	            rs=st.executeQuery("Select total_pecas,  p7, tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p7=rs.getInt("p7");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p7++;
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	           else if(pa==8 && pb==7){
	            rs=st.executeQuery("Select total_pecas,  p8, tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p8=rs.getInt("p8");
	                    
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p8++;
	                 
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p8="+p8+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	       else if(pa==7 && pb==9){
	            rs=st.executeQuery("Select total_pecas,  p7, tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p7=rs.getInt("p7");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p7++;
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
	                 
	                 rs.close();
	                 st.close();
	       }
	
	       
	       
	       else if(pa==8 && pb==9){
	            rs=st.executeQuery("Select total_pecas,  p8, tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p2=rs.getInt("p2");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p8++;
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p2="+p2+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	                 
	                 
	                 rs=st.executeQuery("Select total_pecas,  p3, tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p8=rs.getInt("p8");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p8++;
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p8="+p8+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
	              
	                 rs.close();
	                 st.close();
	       }
	       
	       
	       
	       else if(pa==1 && pb==8){
	           rs=st.executeQuery("Select total_pecas,  p1, p3, p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p1=rs.getInt("p1");
	                    p3=rs.getInt("p3");
	                    p5=rs.getInt("p5");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p1++;
	                 p3++;
	                 p5++;
	                 tempo=tempo+5+10+5;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p1="+p1+", p3="+p3+", p5="+p5+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	                 
	                 
	                 rs=st.executeQuery("Select total_pecas,  p7,tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p7=rs.getInt("p7");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p7++;
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
	              
	                 rs.close();
	                 st.close();
	       }
	      else if(pa==1 && pb==9){
	    	  rs=st.executeQuery("Select total_pecas,  p1, p3, p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
              
              while (rs.next()){
                 total=rs.getInt("total_pecas");
                 p1=rs.getInt("p1");
                 p3=rs.getInt("p3");
                 p5=rs.getInt("p5");
                 tempo=rs.getInt("tempo");
              }
              total++;
              p1++;
              p3++;
              p5++;
              tempo=tempo+5+10+5;
              st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p1="+p1+", p3="+p3+", p5="+p5+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
              
              
              rs=st.executeQuery("Select total_pecas,  p7,tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
              
              while (rs.next()){
                 total=rs.getInt("total_pecas");
                 p7=rs.getInt("p7");
                 tempo=rs.getInt("tempo");
              }
              total++;
              p7++;
              tempo=tempo+20;
              st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
           
              rs.close();
              st.close();
    }
	       
	      else if(pa==3 && pb==8){
	    	  rs=st.executeQuery("Select total_pecas,  p3, p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
              
              while (rs.next()){
                 total=rs.getInt("total_pecas");
                 p3=rs.getInt("p3");
                 p5=rs.getInt("p5");
                 tempo=rs.getInt("tempo");
              }
              total++;
             
              p3++;
              p5++;
              tempo=tempo+10+5;
              st.executeUpdate( "UPDATE maquinas set total_pecas="+total+", p3="+p3+", p5="+p5+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
              
              
              rs=st.executeQuery("Select total_pecas,  p7,tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
              
              while (rs.next()){
                 total=rs.getInt("total_pecas");
                 p7=rs.getInt("p7");
                 tempo=rs.getInt("tempo");
              }
              total++;
              p7++;
              tempo=tempo+20;
              st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
           
              rs.close();
              st.close();
    }
	       else if(pa==3 && pb==9){
	    	   rs=st.executeQuery("Select total_pecas,  p3, p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
	              
	              while (rs.next()){
	                 total=rs.getInt("total_pecas");
	                 p3=rs.getInt("p3");
	                 p5=rs.getInt("p5");
	                 tempo=rs.getInt("tempo");
	              }
	              total++;
	             
	              p3++;
	              p5++;
	              tempo=tempo+10+5;
	              st.executeUpdate( "UPDATE maquinas set total_pecas="+total+", p3="+p3+", p5="+p5+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	              
	              
	              rs=st.executeQuery("Select total_pecas,  p7,tempo  from maquinas Where tipo='C' and celula='"+celula+"'");
	              
	              while (rs.next()){
	                 total=rs.getInt("total_pecas");
	                 p7=rs.getInt("p7");
	                 tempo=rs.getInt("tempo");
	              }
	              total++;
	              p7++;
	              tempo=tempo+20;
	              st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='C' and celula='"+celula+"'");  
	           
	              rs.close();
	              st.close();
	    }
	       else if(pa==5 && pb==8){
	           rs=st.executeQuery("Select total_pecas,  p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p5=rs.getInt("p5");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 p5++;
	                 tempo=tempo+5;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p4="+p4+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
	                 
	                 
	                 rs=st.executeQuery("Select total_pecas,  p7, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
	                 
	                 while (rs.next()){
	                    total=rs.getInt("total_pecas");
	                    p7=rs.getInt("p2");
	                    tempo=rs.getInt("tempo");
	                 }
	                 total++;
	                 
	                 p7++;
	                 tempo=tempo+20;
	                 st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p2="+p2+", p6="+p6+", tempo='"+tempo+"' WHERE tipo='B' and celula='"+celula+"'");  
	              
	                 rs.close();
	                 st.close();
	       }
	        else if(pa==5 && pb==9){
	            rs=st.executeQuery("Select total_pecas,  p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
                
                while (rs.next()){
                   total=rs.getInt("total_pecas");
                   p5=rs.getInt("p5");
                   tempo=rs.getInt("tempo");
                }
                total++;
                p5++;
                tempo=tempo+5;
                st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p5="+p5+",tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'");  
                
                
                rs=st.executeQuery("Select total_pecas,  p7, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
                
                while (rs.next()){
                   total=rs.getInt("total_pecas");
                   p7=rs.getInt("p7");
                   tempo=rs.getInt("tempo");
                }
                total++;
                
                p7++;
                tempo=tempo+20;
                st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p7="+p7+", tempo='"+tempo+"' WHERE tipo='B' and celula='"+celula+"'");  
             
                rs.close();
                st.close();
	        }
	        else if(pa==1 && pb==5){
	            rs=st.executeQuery("Select total_pecas,  p1, p3, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
                
                while (rs.next()){
                   total=rs.getInt("total_pecas");
                   p1=rs.getInt("p1");
                   p3=rs.getInt("p3");
                   tempo=rs.getInt("tempo");
                }
                total++;
                p1++;
                p3++;
                tempo=tempo+10+5;
                st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p1="+p1+", p3="+p3+", tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'"); 
                rs.close();
                st.close();
               }
	       
	        else if(pa==1 && pb==7){
	            rs=st.executeQuery("Select total_pecas,  p1, p3, p5, tempo  from maquinas Where tipo='A' and celula='"+celula+"'");
                
                while (rs.next()){
                   total=rs.getInt("total_pecas");
                   p1=rs.getInt("p1");
                   p3=rs.getInt("p3");
                   p5=rs.getInt("p5");
                   tempo=rs.getInt("tempo");
                }
                total++;
                p1++;
                p3++;
                p5++;
                tempo=tempo+5+10+5;
                st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p1="+p1+", p3="+p3+", p5="+p5+", tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'"); 
                rs.close();
                st.close();
               }
	       
	        else if(pa==2 && pb==6){
	            rs=st.executeQuery("Select total_pecas,  p2, p4, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
                
                while (rs.next()){
                   total=rs.getInt("total_pecas");
                   p2=rs.getInt("p2");
                   p4=rs.getInt("p4");
                   
                   tempo=rs.getInt("tempo");
                }
                total++;
                p2++;
                p4++;
                tempo=tempo+10+5;
                st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p1="+p1+", p3="+p3+", p5="+p5+", tempo='"+tempo+"' WHERE tipo='A' and celula='"+celula+"'"); 
                rs.close();
                st.close();
               }
	       
	        else if(pa==2 && pb==8){
	            rs=st.executeQuery("Select total_pecas,  p2, p4, p6, tempo  from maquinas Where tipo='B' and celula='"+celula+"'");
                
                while (rs.next()){
                   total=rs.getInt("total_pecas");
                   p2=rs.getInt("p2");
                   p4=rs.getInt("p4");
                   p6=rs.getInt("p6");
                   
                   tempo=rs.getInt("tempo");
                }
                total++;
                p2++;
                p4++;
                p6++;
                tempo=tempo+10+5;
                st.executeUpdate( "UPDATE maquinas set total_pecas="+total+",p2="+p2+", p4="+p4+", p6="+p6+", tempo='"+tempo+"' WHERE tipo='B' and celula='"+celula+"'"); 
                rs.close();
                st.close();
               }
	       
	     }
	       
	     catch(Exception ex)
	     {
	         System.out.print(ex);
	     }
	
	}
}